/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aiproject1;

/**
 *
 * @author MSA
 */
public class h {
 private char c1;
    private float linkCost;

    public h(char c1,float cost) {
        this.c1 = c1;
        this.linkCost = cost;
    }

    public char getC1() {
        return c1;
    }

    public void setC1(char c1) {
        this.c1 = c1;
    }
  public float getLinkCost() {
        return linkCost;
    }

    public void setLinkCost(float linkCost) {
        this.linkCost = linkCost;
    }

}
