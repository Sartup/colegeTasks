/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author MSA
 */
public final class AStar {
    String e="";
     ArrayList <Character> y= new ArrayList();
    public AStar(ArrayList<link>l,ArrayList<h>n){
        Scanner s = new Scanner(System.in);
        System.out.println("enter two nodes");
        node a1 = new node(s.next().charAt(0), null, null,0, false);
        node b1=new node(s.next().charAt(0),null,null,0.0f,false);
        list j = new list(a1,null);
        node tmp = a1;
        while (tmp != null) {   
                Expand(tmp,l,j); 
                remove(j,n,tmp);
                tmp = tmp.getpNext();
            
            }
         
      printResult(a1,b1);
    }
    
     public void Expand(node t,ArrayList<link> links, list f) {
        node temp;
        boolean found;
        for (int i = 0; i < links.size(); i++) {
            found = false;
            temp = null;
            if (t.getName() == links.get(i).getC1()) {
                found = true;
                
                temp = new node(links.get(i).getC2(), t, null,t.getCost()+links.get(i).getLinkCost(), false);
              //  System.out.println(temp.getName());

            } else if (t.getName() == links.get(i).getC2()) {
                found = true;
          
                temp = new node(links.get(i).getC1(), t, null,t.getCost()+links.get(i).getLinkCost(), false);
                /// System.out.println(temp.getName());

            } 
              if ((found == true) && (qualified(f,temp))&&exist(temp)) {
           
                pushnode(f,temp);
            }  
        }

    }
        public void printResult(node a,node n) {
        
       node t=a;
       node tmp=null;
       while(t!=null)
       {
       if(t.getName()==n.getName())
       {tmp=t;
       break;}
       
        t=t.getpNext();
       }
        t=a;
       while(t!=null)
       {
       if(t.getName()==n.getName())
           if(t.getCost()<tmp.getCost())
             tmp=t;
        t=t.getpNext();
       }
       System.out.println("the totsl cost:"+tmp.getCost());
       while(tmp!=null)
       {
        e +=tmp.getName();
        tmp=tmp.getpParent(); 
       }
       System.out.print("the result = ");
       for(int i=e.length()-1;i>=0;i--)
            
     System.out.print(e.charAt(i));
    }
        public boolean qualified(list frontier,node n) {
        node temp = frontier.getpFirstNode();
        node pre=null;
        if (frontier.getpFirstNode().getName() == n.getName()) {
            return false;
        }
        

        while (temp != null) {
            
            if (temp.getName() == n.getName()) {
                if (temp.getCost() > n.getCost()) {

                   // temp.pParent.pNext = temp.pNext;
                    pre.setpNext(temp.getpNext());
                   // temp.pNext = null;
                    return true;
                }
                else{
                    return false;
                }
            }
            pre=temp;
            temp = temp.getpNext();
        }
        return true;
    }
     public boolean exist(node n){
        if(y==null)
            return true;
        else{
      for(int i=0;i<y.size();i++)
      {
       if(n.getName()==y.get(i))
         return false;
      }}
    return true;
    }
      public void remove(list f,ArrayList<h> a,node t){
   node tmp=t.getpNext();
   node cu=null;
   while(cu!=null)
   { cu=tmp.getpNext();
     if(tmp.cost(tmp.getName(),a)+tmp.getCost()<cost(cu.getName(),a)+cu.getCost())
     { tmp.setpNext(cu.getpNext());
       y.add(cu.getName());
       cu=cu.getpNext(); 
        f.printList();
     }
     else 
     {t.setpNext(cu);
     System.out.println(tmp.getName());
      y.add(tmp.getName());
       tmp=tmp.getpNext();
       cu=cu.getpNext();
       f.printList();
     }
        
  }
  }
       public void pushnode(list f,node t) {
        if (f.getpFirstNode().getpNext() == null) {
            f.getpFirstNode().setpNext(t);
            f.setpLastNode(t);
        } else {
            f.getpLastNode().setpNext(t);
            f.setpLastNode(t);
        }

    }
       public float cost(char c,ArrayList<h> a){
    
     for(int i=0;i<a.size();i++)
     {  
         if(a.get(i).getC1()==c)
     {    
         return a.get(i).getLinkCost();
     }}
    return 0;
  }
}