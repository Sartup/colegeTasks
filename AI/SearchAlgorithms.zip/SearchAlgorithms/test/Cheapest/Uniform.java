/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cheapest;

import java.util.ArrayList;

/**
 *
 * @author 
 */
public class Uniform {

    char node1;
    char node2;
    int value;
    ArrayList<Uniform> NameNode = new ArrayList();
    ArrayList<Uniform> temp = new ArrayList();
    ArrayList<Uniform> explored = new ArrayList();
    ArrayList<Uniform> forinter = new ArrayList();

    Uniform() {
        this.node1=0 ;
        this.node2 = 0;
        this.value = 0;
    }

    Uniform(char n1, char n2, int n) {
        this.node1 = n1;
        this.node2 = n2;
        this.value = n;

    }

    public char getNode1() {
        return node1;
    }

    public void setNode1(char node1) {
        this.node1 = node1;
    }

    public char getNode2() {
        return node2;
    }

    public void setNode2(char node2) {
        this.node2 = node2;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public ArrayList<Uniform> getNameNode() {
        return NameNode;
    }

    public void setNameNode(ArrayList<Uniform> NameNode) {
        this.NameNode = NameNode;
    }

    public void graph() {

        Uniform nod1 = new Uniform('A', 'B', 4);
        Uniform nod2 = new Uniform('A', 'C', 1);
        Uniform nod3 = new Uniform('A', 'D', 3);
        Uniform nod4 = new Uniform('B', 'C', 8);
        Uniform nod5 = new Uniform('C', 'D', 3);
        Uniform nod6 = new Uniform('C', 'G', 2);
        Uniform nod7 = new Uniform('D', 'C', 3);
        Uniform nod12 = new Uniform('D', 'G', 4);
        Uniform nod14 = new Uniform('G', 'E', 6);

        NameNode.add(nod1);
        NameNode.add(nod2);
        NameNode.add(nod3);
        NameNode.add(nod4);
        NameNode.add(nod5);
        NameNode.add(nod6);
        NameNode.add(nod7);
//        NameNode.add(nod8);
//        NameNode.add(nod9);
//        NameNode.add(nod10);
//        NameNode.add(nod11);
        NameNode.add(nod12);
//        NameNode.add(nod13);
        NameNode.add(nod14);

    }

    public void Start(char start, char end) {
        boolean flag = true;
        boolean wlag = true;

        boolean out = true;

        int x = 0;

        while (!NameNode.isEmpty() && flag) {
            if (start != end) {
                flag = true;

                if (start == NameNode.get(x).getNode1()) {

                    flag = false;
                    wlag = true;
                    for (int i = x; i < NameNode.size(); i++) {
                        if (wlag == true) {
                            temp.add(NameNode.get(x));
                            for (int j = i + 1; j < NameNode.size(); j++) {

                                if (NameNode.get(x).node1 == NameNode.get(j).node1) {
                                    temp.add(NameNode.get(j));
                                    wlag = false;

                                }
                            }

                        }

                    }
                    ///////SORT///////
                    if (temp.size() > 0) {
                        for (int u = 0; u < temp.size(); u++) {
                            forinter.add(temp.get(u));
                            for (int z = u + 1; z < temp.size(); z++) {

                                if (temp.get(u).getValue() > temp.get(z).getValue()) {
                                    int value;
                                    char node2;
                                    node2 = temp.get(z).node2;
                                    value = temp.get(z).getValue();
                                    temp.get(z).value = temp.get(u).value;
                                    temp.get(z).node2 = temp.get(u).node2;
                                    temp.get(u).value = value;
                                    temp.get(u).node2 = node2;

                                }

                            }

                        }
                    }
                    if (temp.size() > 0) {
                        explored.add(temp.get(0));

                        start = temp.get(0).node2;
                        flag = true;
                        temp.clear();
                        x = 0;

                        if (end==NameNode.get(x).node2) {
                            explored.add(new Uniform(start, '\0', 0));
                            forinter.add(new Uniform(start, '\0', 0));
                            flag = false;
                            out = false;
                        }
                        if (out == true) {
                            Start(start, end);
                        }
                    }
                } else {
                    x++;
                }

            }
            if (start == end) {
                explored.add(new Uniform(start, '\0', 0));
                forinter.add(new Uniform(start, '\0', 0));
                flag = false;
            }

        }

        int sum = 0;
        for (int o = 0; o < explored.size(); o++) {
            System.out.println("explored: node1: " + explored.get(o).node1
                    + " node2: " + explored.get(o).node2
                    + " cost: " + explored.get(o).value);
            sum += explored.get(o).value;

        }
        for (int o = 0; o < explored.size(); o++) {
            System.out.print(" " + explored.get(o).node1 + " : ");

        }
        System.out.println("sum: " + sum);

        System.exit(0);

    }

}
