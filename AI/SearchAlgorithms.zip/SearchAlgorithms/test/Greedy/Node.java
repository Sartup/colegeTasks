/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Greedy;

/**
 *
 * @author Alhassan
 */
public class Node {
    char startNode;
    char endNode;
    float cost;
    boolean visited;

    public char getStartNode() {
        return startNode;
    }

    public void setStartNode(char startNode) {
        this.startNode = startNode;
    }

    public char getEndNode() {
        return endNode;
    }

    public void setEndNode(char endNode) {
        this.endNode = endNode;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public Node(char startNode, char endNode, float cost, boolean visited) {
        this.startNode = startNode;
        this.endNode = endNode;
        this.cost = cost;
        this.visited = visited;
    }
    public Node() {
        this.startNode = 0;
        this.endNode = 0;
        this.cost = 0;
        this.visited = false;
    }
}
