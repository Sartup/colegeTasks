/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Greedy;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Alhassan
 */
public class NewGreedy {

    void graphDesing() {

        ArrayList<Node> graph = new ArrayList<>();
        graph.add(new Node('A', 'B', 4, false));
        graph.add(new Node('A', 'C', 1, false));
        graph.add(new Node('B', 'D', 3, false));
        graph.add(new Node('B', 'E', 8, false));
        graph.add(new Node('C', 'D', 2, false));
        graph.add(new Node('C', 'F', 6, false));

        graph.add(new Node('D', 'E', 4, false));

        graph.add(new Node('E', 'G', 2, false));
        graph.add(new Node('F', 'G', 8, false));

        HashMap<Character, Integer> value = new HashMap<>();
        value.put('A', 8);
        value.put('B', 8);
        value.put('C', 6);
        value.put('D', 5);
        value.put('E', 1);
        value.put('F', 4);
        value.put('G', 0);

        ArrayList<Node> frontier = new ArrayList<>();
        ArrayList<Node> explored = new ArrayList<>();
        ArrayList<Node> temp = new ArrayList<>();
        ArrayList<Node> tempClear = new ArrayList<>();

        char start = 'A';
        char end = 'G';
        explored.add(new Node(start, ' ', 0, true));
        frontier.add(new Node(start, ' ', 0, true));
        boolean flag = true, finished = false;
        char newString = ' ';
        boolean wlag = true;
        boolean ifFlag = true;
        while (!graph.isEmpty() & flag == true) {
            for (int i = 0; i < graph.size(); i++) {
                if (finished == false) {
                    if (ifFlag == true) {
                        if (start == end) {
                            flag = false;
                            ifFlag = false;
                            finished = true;
                            break;

                        }
                    }
                    if (end == (graph.get(i).startNode)) {
                        frontier.add(new Node(graph.get(i).startNode, ' ', 1, true));
                        explored.add(new Node(graph.get(i).startNode, ' ', 0, true));
                        flag = false;
                        end = start;
                        finished = true;
                        break;
                    }
                    if (start == (graph.get(i).startNode)) {
                        char startNode = graph.get(i).startNode;
                        temp.add(graph.get(i));
                        for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {
                            if (graph.get(i).endNode == (loop.getKey())) {
                                frontier.add(new Node(graph.get(i).startNode, graph.get(i).endNode, loop.getValue(), true));
                            }
                        }
                        for (int x = i + 1; x < graph.size(); x++) {
                            if (startNode == (graph.get(x).startNode)) {
                                temp.add(graph.get(x));
                                for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {
                                    if (graph.get(x).endNode == (loop.getKey())) {
                                        frontier.add(new Node(graph.get(x).startNode, graph.get(x).endNode, loop.getValue(), true));
                                    }
                                }

                                wlag = false;

                                newString = graph.get(x).startNode;

                            }
                        }
                    }
                    if (temp.size() > 0) {
                        for (int y = 0; y < temp.size(); y++) {

                            for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {

                                if (temp.get(y).endNode == (loop.getKey())) {
                                    frontier.add(new Node(loop.getKey(), newString, loop.getValue(), true));
                                    tempClear.add(new Node(temp.get(y).startNode, loop.getKey(), loop.getValue(), true));
                                }
                            }

                        }
                    }
                    if (temp.size() > 0) {
                        temp.clear();
                    }
                    if (tempClear.size() > 0) {
                        for (int o = 0; o < tempClear.size(); o++) {
                            for (int t = o + 1; t < tempClear.size(); t++) {
                                if (tempClear.get(o).cost > tempClear.get(t).cost) {
                                    int swapValue;
                                    char swapEndNode;
                                    swapEndNode = tempClear.get(t).endNode;
                                    swapValue = (int) tempClear.get(t).cost;
                                    tempClear.get(t).endNode = tempClear.get(o).endNode;
                                    tempClear.get(t).cost = tempClear.get(o).cost;
                                    tempClear.get(o).endNode = swapEndNode;
                                    tempClear.get(o).cost = swapValue;
                                }

                            }
                        }
                    }
                    if (tempClear.size() > 0) {
                        explored.add(new Node(tempClear.get(0).startNode, tempClear.get(0).endNode, tempClear.get(0).cost, true));
                        start = tempClear.get(0).endNode;
                        tempClear.clear();
                    }
                }

            }

        }
        for (Node print : frontier) {
            System.out.println("frontier: " + print.startNode + " : " + print.endNode + " : " + print.cost);

        }
        System.out.println("--------------------------------");

        if (explored.size() == 0) {

        } else {

        }
        System.out.println("explored: ");
        for (Node print : explored) {
            
            System.out.print( print.startNode + " : " + print.endNode + " : "  );
            System.out.println(print.cost);
        }
        int newCost = 0;
        boolean out = true;
        for (int hh = 0; hh < explored.size(); hh++) {

            out = true;

            for (int h = 0; h < graph.size(); h++) {

                if (out == true) {
                    if (explored.get(hh).startNode == graph.get(h).startNode && explored.get(hh).endNode == graph.get(h).endNode && out == true) {
                        newCost += graph.get(h).cost;
                        out = false;
                    }
                    if (explored.get(hh).endNode == ' ') {
                        newCost += 0;
                        out = false;
                    }

                }

            }
        }
        System.out.println("cost: " + newCost);
        System.out.println("--------------------------------");
        System.out.println("--------------------------------");

    }

    public static void main(String[] args) {

        NewGreedy obj = new NewGreedy();
        System.out.println("Gready---------------->");
        obj.graphDesing();

    }

}

