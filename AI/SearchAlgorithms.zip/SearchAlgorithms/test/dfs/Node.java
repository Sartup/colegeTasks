/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs;

/**
 *
 * @author AbdelRaman
 */
public class Node {
    char startNode;
    char endNode;
    float cost;


    public Node(char startNode, char endNode ) {
        this.startNode = startNode;
        this.endNode = endNode;
    }

    public char getStartNode() {
        return startNode;
    }

    public void setStartNode(char startNode) {
        this.startNode = startNode;
    }

    public char getEndNode() {
        return endNode;
    }

    public void setEndNode(char endNode) {
        this.endNode = endNode;
    }


    void add(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}