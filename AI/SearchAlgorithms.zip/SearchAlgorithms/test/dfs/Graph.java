/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs;

import java.util.ArrayList;

/**
 *
 * @author AbdelRaman
 */
public class Graph {
       void DFS() {
        ArrayList<Node> graph = new ArrayList<>();
        ArrayList<Character> explored = new ArrayList<>();
       // ArrayList<Node> frointer = new ArrayList<>();

        graph.add(new Node('A', 'B'));
        graph.add(new Node('A', 'C'));
        graph.add(new Node('B', 'D'));
        graph.add(new Node('D', 'E'));
        graph.add(new Node('B', 'E'));
        graph.add(new Node('C', 'F'));
        graph.add(new Node('C', 'D'));
        graph.add(new Node('E', 'G'));
        graph.add(new Node('F', 'G'));
        char StartNode = 'A';
        char GoalNode = 'G';
        
        for (int x = 0; x < graph.size(); x++) {

            if (StartNode == graph.get(x).startNode) {
                explored.add(StartNode);
                StartNode = graph.get(x).endNode;
                if(StartNode == GoalNode){
                    explored.add(GoalNode);
                }

            }

        }
        for (Character loop : explored) {
            System.out.println(loop);
        }
    }
}