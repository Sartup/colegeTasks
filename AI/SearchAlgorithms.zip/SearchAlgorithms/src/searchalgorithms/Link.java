package searchalgorithms;

/**
 *
 * @author eslam
 */
public class Link {
    
    private char c1, c2;
    private float linkCost;
    private boolean visited;

    public Link() {
    }

    public Link(char c1, char c2, float linkCost) {
        this.c1 = c1;
        this.c2 = c2;
        this.linkCost = linkCost;
    }
    
    public Link(char c1, char c2) {
        this.c1 = c1;
        this.c2 = c2;
    }
    
    public Link(char c1, char c2, float linkCost, boolean visited) {
        this.c1 = c1;
        this.c2 = c2;
        this.linkCost = linkCost;
        this.visited = visited;
    }

    
    
    public void setC1(char c1) {
        this.c1 = c1;
    }
    
    public char getC1() {
        return c1;
    }
    
    public void setC2(char c2) {
        this.c2 = c2;
    }
    
    public char gatC2() {
        return c2;
    }
    
    public void setLinkCost(float linkCoast) {
        this.linkCost = linkCoast;
    }
    
    public float getLinkCost() {
        return linkCost;
    }
    
    public void setVisited(boolean visited) {
        this.visited = visited;
    }
    
    public boolean getVisited() {
        return this.visited;
    }

}
