package searchalgorithms;

import java.util.ArrayList;

/**
 *
 * @author AbdelRaman
 */
public class Breadth {
    
    
    
    void start(ArrayList<Link> graph, char goal) {
      
        // ArrayList<Link> graph = new ArrayList<>();
        ArrayList<Character> explored = new ArrayList<>();
        //ArrayList<Link> frointer = new ArrayList<>();

        char source = graph.get(0).getC1();
        //char goal = graph.get(graph.size()-1).gatC2();
        
        boolean out = true;
        if (source == goal) {
            explored.add(goal);
        }
        if (goal != source && out == true) {
            while (!graph.isEmpty() && out == true) {
                for (int x = 0; x < graph.size(); x++) {
                    if (explored.size() > 0) {

                        char start = graph.get(x).getC1();
                        char end = graph.get(x).gatC2();
                        int indexTwo = explored.indexOf(end);
                        int index = explored.indexOf(start);
                        if (goal == start) {
                            out = false;
                            explored.add(start);
                            break;
                        }
                        if (goal == end) {
                            out = false;
                            explored.add(goal);
                            break;
                        }
                        if (index == -1) {
                            explored.add(start);

                        }

                        if (indexTwo == -1) {
                            explored.add(end);
                        }

                    } else {
                        explored.add(graph.get(x).getC1());
                        explored.add(graph.get(x).gatC2());
                    }

                }
            }
        }
        System.out.print("Solution path: ");

        for (int x = 0; x < explored.size(); x++) {
            System.out.print(explored.get(x) + " ");
        }

    }
}

