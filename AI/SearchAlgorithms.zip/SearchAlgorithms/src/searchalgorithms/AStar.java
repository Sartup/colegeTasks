package searchalgorithms;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author eslam
 */
public class AStar {

    int counter = 0;
    char name, next, parent;
    float cost;
    boolean explored = false;
    AStar newNode;
    LinkedList<AStar> graphList = new LinkedList<>();
    LinkedList<AStar> pFrontier = new LinkedList<>();
    ArrayList<hGoal> huristicList = new ArrayList<>();
    

    public AStar(char name, char next, char parent, float cost, boolean explored) {
        this.name = name;
        this.next = next;
        this.parent = parent;
        this.cost = cost;
        this.explored = explored;
    }

    public AStar(char next, char parent, float cost, boolean explored) {
        this.next = next;
        this.parent = parent;
        this.cost = cost;
        this.explored = explored;
    }
    
    public AStar(){
    }

    
    public LinkedList<AStar> expand(ArrayList<Link> linkList) {
         
        for (int i = 0; i < linkList.size(); i++) {

            name = linkList.get(i).getC1();
            for (int j = i; j < linkList.size(); j++) {

                if (linkList.get(i).getC1() == linkList.get(j).getC1()) {
                    cost = linkList.get(i).getLinkCost();
                    next = linkList.get(i).gatC2();
                        
                    for (int x = 0; x < linkList.size(); x++) {
                        
                        if (name == linkList.get(x).gatC2()) {
                            parent = linkList.get(x).getC1();
                            break;
                            //System.out.println("found");
                        } else {
                            parent = 0;
                            //System.out.println("notfound");
                        }
                    }

                    newNode = new AStar(name, next, parent, cost, explored);
                    graphList.add(newNode);
                    
                    counter++;
                }
                break;
            }
        }
        return graphList;
    }
    public ArrayList<hGoal> getHuristicData(LinkedList<AStar> graphList) {

        this.graphList = graphList;
        System.out.println("Enter Huristic data: ");
        System.err.println("-------------------- ");

        Scanner scan = new Scanner(System.in);
        char letter;
        float nodeCost;
        char[] nodesArray = new char[100];
        boolean nameFound = false, nextFound = false;
        hGoal goalNode;

        for (int i = 0; i < graphList.size(); i++) {
            for (int j = 0; j < nodesArray.length; j++) {

                if (graphList.get(i).name == nodesArray[j]) {
                    nameFound = true;
                    break;
                }
            }
            for (int x = 0; x < nodesArray.length; x++) {

                if (graphList.get(i).next == nodesArray[x]) {
                    nextFound = true;
                    break;
                }
            }

            if (nameFound == false) {
                letter = graphList.get(i).name;
                nodesArray[i] = letter;
                System.out.print("hGoal ( " + letter + " ) = ");
                nodeCost = scan.nextFloat();
                goalNode = new hGoal(letter, nodeCost);
                huristicList.add(goalNode);
                //System.out.println();
            } 
            
            else if (nextFound == false) {
                letter = graphList.get(i).next;
                nodesArray[i] = letter;
                System.out.print("hGoal ( " + letter + " ) = ");
                nodeCost = scan.nextFloat();
                goalNode = new hGoal(letter, nodeCost);
                huristicList.add(goalNode);
                //System.out.println();
            }
            nameFound = false;
            nextFound = false;
        }

        return huristicList;
    }

    char goal;
    
    boolean isGoalCity = false;
    public LinkedList<AStar> frontier(ArrayList<hGoal> huristicList) {
        
        this.huristicList = huristicList;
        //huristicList = getHuristicData(graphList);
        
        char start = huristicList.get(0).getC1();
        goal = huristicList.get(huristicList.size()-1).getC1();
        float huristicCost = 0, listCost = 0;
        if(isGoalCity == false)
        {
          for (int i = 0; i < graphList.size(); i++) {
            for (int j = i+1; j < graphList.size(); j++) {
                if(pFrontier.isEmpty() == true) {
                    next = 0;
                    parent = 0;
                    cost = 0;
                    explored = true;
                    newNode = new AStar(start, next, cost, explored);
                    pFrontier.add(newNode);
                    break;
                }
                
                else {
                    
                    name = graphList.get(i).name;
                    
                    if(name == graphList.get(j).name && graphList.get(j).explored == false) {
                        parent = name;
                        next = graphList.get(j).next;
                        for(int x=0; x<huristicList.size(); x++) {
                            if(parent == huristicList.get(x).getC1()) {
                                huristicCost = huristicList.get(x).getCost();
                            }
                        }
                        cost = graphList.get(j).cost + huristicCost + listCost;
                        graphList.get(j).explored = true;
                        newNode = new AStar(parent, next, cost, explored);
                        pFrontier.add(newNode);
                        
                        for(int m=0; m<pFrontier.size(); m++) {
                            for( int z=m; z<pFrontier.size(); z++) {
                                if(pFrontier.get(m).parent == pFrontier.get(z).parent) {
                                    if(pFrontier.get(m).cost < pFrontier.get(z).cost) {
                                        pFrontier.remove(z);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                    
                }
                
            }
        }
        
        
        return pFrontier;
    }
    
    public void printSolution(LinkedList<AStar> pFrontier) {
       
        float pathCost = 0;
        char pathNode;
        System.out.print("\nPath :");
        for (AStar aStar : pFrontier) {
            pathNode = aStar.next;
            System.out.print(pathNode + "-->");
            pathCost += aStar.cost;
        }
        System.out.println(goal);
        
        System.out.println("\npathCost = " + pathCost);
    }
    
    
//    public void printPFrontier(LinkedList<AStar> pFrontier) {
//        this.pFrontier = pFrontier;
//        for (int i = 0; i < pFrontier.size(); i++) {
//            name = pFrontier.get(i).name;
//            next = pFrontier.get(i).next;
//            parent = pFrontier.get(i).parent;
//            cost = pFrontier.get(i).cost;
//            explored = pFrontier.get(i).explored;
//            System.out.println(name + "  " + next + "  " + parent + "  " + cost + "  " + explored);
//        }
//    }
}

