/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchalgorithms;

/**
 *
 * @author eslam
 */
public class List {
    
    private Node pNode, pLastNode;

    public List() {
    }

    public List(Node pNode, Node pLastNode) {
        this.pNode = pNode;
        this.pLastNode = pLastNode;
    }
    
    public void printList(Node node) {
        System.out.println("name\t" + "parent's name\t" + "cost");
        System.out.println(node.getName() + "\t" 
                + node.getpParent().getName() + "\t\t" 
                + node.getCost());
    }
    
    /*this function "PrintResult"  is to print (to console) the solution path along with its cost. It should also
    display number of nodes expanded (i.e. how many times the method
    node::expand(vector<link>, list*) was called */
    public void printResult() {
        char[] path;
        
        
    }

    public Node getpNode() {
        return pNode;
    }

    public void setpNode(Node pNode) {
        this.pNode = pNode;
    }

    public Node getpLastNode() {
        return pLastNode;
    }

    public void setpLastNode(Node pLastNode) {
        this.pLastNode = pLastNode;
    }
    
    
}
