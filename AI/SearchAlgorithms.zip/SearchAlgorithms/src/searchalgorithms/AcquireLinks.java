package searchalgorithms;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author eslam
 */
public class AcquireLinks {
    
    ArrayList<Link> linkList = new ArrayList<>();
    private char c1, c2;
    private float linkCost;
    
    public ArrayList<Link> readFile() throws FileNotFoundException{
    
        //file path = "/media/eslam/Win/Semester-6/Artificial Intelligence/project1/SearchAlgorithms/file.txt"
        
        String filePath="file.txt";
    
        BufferedReader br = null;
        FileReader fr = null;
    
        try {
            
            fr = new FileReader(filePath);
            br = new BufferedReader(fr);
    
            String line;
            
            while((line = br.readLine()) != null) {
                c1 = line.charAt(0);
                c2 = line.charAt(2);
                linkCost = Float.parseFloat(line.substring(4));
                
                linkList.add(new Link(c1, c2, linkCost));

            }
            
        } catch (IOException ex) {
           
            ex.printStackTrace();
        
        } finally {
            
            try {
                
                if (br != null)
                    br.close();
                
                if(fr != null)
                   fr.close();
            
            } catch (IOException ex) {
                
                ex.printStackTrace();
            }
        }   
        
        
        return linkList;
    }
    
//    public void printList(ArrayList<Link> l) {
//        l = linkList;
//        System.out.println("Name\t" + "Parent's Name\t" + "Cost");
//        for(int i=0; i<l.size(); i++) {
//            System.out.println(l.get(i).getC1() +"\t    " 
//                    + l.get(i).gatC2() +"\t\t"
//                    + l.get(i).getLinkCost());
//        }
//    }
}

