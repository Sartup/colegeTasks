package searchalgorithms;

import java.util.ArrayList;

/**
 *
 * @author Omar
 */
public class Cheapest {

    char c1;
    char c2;
    float cost;
    ArrayList<Link> NameNode = new ArrayList();
    ArrayList<Link> temp = new ArrayList();
    ArrayList<Link> explored = new ArrayList();
    ArrayList<Link> forinter = new ArrayList();

    

    public void graph(ArrayList<Link> NameNode) {
        this.NameNode = NameNode;
    }
    
    
    public void Start(char start, char end) {
        
        //char start = NameNode.get(0).getC1();
        //char end = NameNode.get(NameNode.size()-1).gatC2();
        boolean flag = true;
        boolean wlag = true;

        boolean out = true;

        int x = 0;

        while (!NameNode.isEmpty() && flag) {
            if (start != end) {
                flag = true;

                if (start == NameNode.get(x).getC1()) {

                    flag = false;
                    wlag = true;
                    for (int i = x; i < NameNode.size(); i++) {
                        if (wlag == true) {
                            temp.add(NameNode.get(x));
                            for (int j = i + 1; j < NameNode.size(); j++) {

                                //  if (NameNode.get(x).node1 == NameNode.get(j).node1)
                                if (NameNode.get(x).getC1() == NameNode.get(j).getC1()) {
                                    temp.add(NameNode.get(j));
                                    wlag = false;

                                }
                            }

                        }

                    }
                    ///////SORT///////
                    if (temp.size() > 0) {
                        for (int u = 0; u < temp.size(); u++) {
                            forinter.add(temp.get(u));
                            for (int z = u + 1; z < temp.size(); z++) {
                                   
                                // (temp.get(u).getValue() > temp.get(z).getValue())    
                                if (temp.get(u).getLinkCost() > temp.get(z).getLinkCost()) {
                                    float value;
                                    char node2;
                                    node2 = temp.get(z).gatC2();
                                    value = temp.get(z).getLinkCost();
                                    temp.get(z).setLinkCost(temp.get(u).getLinkCost());
                                    temp.get(z).setC1(temp.get(u).getC1());
                                    temp.get(u).setLinkCost(value);
                                    temp.get(u).setC2(node2);

                                }

                            }

                        }
                    }
                    if (temp.size() > 0) {
                        explored.add(temp.get(0));

                        start = temp.get(0).gatC2();
                        flag = true;
                        temp.clear();
                        x = 0;

                        if (end==NameNode.get(x).gatC2()) {
                            explored.add(new Link(start, '\0', 0));
                            forinter.add(new Link(start, '\0', 0));
                            flag = false;
                            out = false;
                        }
                        if (out == true) {
                            Start(start, end);
                        }
                    }
                } else {
                    x++;
                }

            }
            if (start == end) {
                explored.add(new Link(start, '\0', 0));
                forinter.add(new Link(start, '\0', 0));
                flag = false;
            }

        }

        int sum = 0;
        for (int o = 0; o < explored.size(); o++) {
            System.out.println("explored: node1: " + explored.get(o).getC1()
                    + " node2: " + explored.get(o).gatC2()
                    + " cost: " + explored.get(o).getLinkCost());
            sum += explored.get(o).getLinkCost();

        }
        for (int o = 0; o < explored.size(); o++) {
            System.out.print(" " + explored.get(o).getC1() + " : ");

        }
        System.out.println("sum: " + sum);

        System.exit(0);

    }

}