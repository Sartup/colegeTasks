package searchalgorithms;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author eslam
 */
public class hGoal {

    private char c1;
    private float cost;
    public ArrayList<hGoal> huristicList = new ArrayList<>();

    public hGoal() {
    }

    public hGoal(char c1, float cost) {
        this.c1 = c1;
        this.cost = cost;
    }

    public char getC1() {
        return c1;
    }

    public void setC1(char c1) {
        this.c1 = c1;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    
}
