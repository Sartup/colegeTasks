/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchalgorithms;

import java.util.ArrayList;

/**
 *
 * @author AbdelRaman
 */
public class DFS {
       
    void dfs(ArrayList<Link> graph, char StartNode, char GoalNode) {
        //ArrayList<Link> graph = new ArrayList<>();
        ArrayList<Character> explored = new ArrayList<>();
       // ArrayList<Node> frointer = new ArrayList<>();

        
        for (int x = 0; x < graph.size(); x++) {

            if (StartNode == graph.get(x).getC1()) {
                explored.add(StartNode);
                StartNode = graph.get(x).gatC2();
                if(StartNode == GoalNode){
                    explored.add(GoalNode);
                }
            }

        }
        for (Character loop : explored) {
            System.out.println(loop);
        }
    }
}

