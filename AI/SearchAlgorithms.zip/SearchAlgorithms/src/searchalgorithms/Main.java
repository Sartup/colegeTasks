package searchalgorithms;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eslam
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        
        // read graph file --> a b 5
        ArrayList<Link> linkList;
        AcquireLinks ac = new AcquireLinks();
        linkList = ac.readFile();
       
        int choice;
        char goalCity = 0, start = 0;
        
        System.out.println("Choose Number OR enter 0 to EXIT ");
        System.out.println("--------------------------------\n");
        System.out.println("(1) Breadth First.");
        System.out.println("(2) Depth First.");
        System.out.println("(3) Cheapest First.");
        System.out.println("(4) Greedy.");
        System.out.println("(5) A* 1");
        System.out.println("\n");
        Scanner scan = new Scanner(System.in);
        System.out.print("Your choice: ");
        choice = scan.nextInt();
        
        while(choice != 0) {
            switch (choice) {
                case 1:
                
                    System.out.println("(1) Breadth First!\n");
                    System.out.print("Enter goal node: ");
                
                    try {
                        goalCity = (char) System.in.read();
                    } catch (IOException ex) {
                        System.out.println("enter character!");
                    }
                
                    Breadth br = new Breadth();
                    br.start(linkList, goalCity);
                    break;
                
                case 2:
                    
                    System.out.println("(2) Depth First!\n");
                    
                    System.out.print("Enter start node: ");
                    start = scan.next().charAt(0);
              
                    System.out.print("Enter goal node: ");
                    goalCity = scan.next().charAt(0);
                    
                    DFS d = new DFS();
                    d.dfs(linkList, start, goalCity);
                    break;
                
                case 3:
                    System.out.println("(3) Cheapest!\n");
                    
                    System.out.print("Enter start node: ");
                    start = scan.next().charAt(0);
              
                    System.out.print("Enter goal node: ");
                    String end = scan.next();
                    goalCity = end.charAt(0);
                    
                    Cheapest ch = new Cheapest();
                    ch.graph(linkList);
                    System.out.println("finished");
                    ch.Start(start, goalCity);
                    break;
                
                case 4:
                    System.out.println("(4) Greedy!\n");
                    
                    NewGreedy obj = new NewGreedy();
                    obj.graphDesing(linkList);
                    
                    break;
                case 5:
                    System.out.println("(5) A* 1\n");
                    
                    AStar as = new AStar();
                    
                    LinkedList<AStar> graphList;
                    graphList = as.expand(linkList);
                    
                    ArrayList<hGoal> huristicList;
                    huristicList = as.getHuristicData(graphList);
                    
                    LinkedList<AStar> pFrontier;
                    pFrontier = as.frontier(huristicList);
                    as.printSolution(pFrontier);
                    
                    break;
                default:
                    break;
            }
            
            System.out.print("\n\nChoose another algorithm or EXIT:");
            choice = scan.nextInt();
        }
    }
}


