package searchalgorithms;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author eslam
 */
public interface SearchInterface {
  
    // class Node
    boolean isGoal(char goalCity);
    void setName(char name);
    char getName();
    void setpParent(Node pParent);
    Node getpParent();
    void setpNext(Node pNext);
    Node getpNext();
    void setCost(float cost);
    float getCost();
    void setExplored(boolean explored);
    boolean getExplored();
    //void expand(ArrayList<Link> linkList, List pFrontier);
    void expand(ArrayList<Link> linkList, LinkedList<Node> pFrontier);
    void pushNodeToList(LinkedList<Node> pFrontier);
    
}
