package searchalgorithms;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Hassan
 */

/*
 startNode = c1;
 endNode = c2;
 cost = linkCost;
*/
public class NewGreedy {
    char c1, c2;
    float linkCost;
    boolean visited;
    
    void graphDesing(ArrayList<Link> linkList) throws FileNotFoundException {

//        ArrayList<Link> linkList;    
//        AcquireLinks ac = new AcquireLinks();
//        linkList = ac.readFile();
        
        ArrayList<Link> graph = new ArrayList<>();
        for (Link link : linkList) {
            c1 = link.getC1();
            c2 = link.gatC2();
            linkCost = link.getLinkCost();
            visited = false;
            link = new Link(c1, c2, linkCost, visited);
            graph.add(link);
        }
        
        
        //huristic data
        HashMap<Character, Integer> value = new HashMap<>();
        value.put('a', 8);
        value.put('b', 8);
        value.put('c', 6);
        value.put('d', 5);
        value.put('e', 1);
        value.put('f', 4);
        value.put('g', 0);


        ArrayList<Link> frontier = new ArrayList<>();
        ArrayList<Link> explored = new ArrayList<>();
        ArrayList<Link> temp = new ArrayList<>();
        ArrayList<Link> tempClear = new ArrayList<>();

        char start = graph.get(0).getC1();
        char end = 0;
        explored.add(new Link(start, ' ', 0, true));
        frontier.add(new Link(start, ' ', 0, true));
        boolean flag = true, finished = false;
        char newString = ' ';
        boolean wlag = true;
        boolean ifFlag = true;
        while (!graph.isEmpty() & flag == true) {
            
            for (int i = 0; i < graph.size(); i++) {
                if (finished == false) {
                    if (ifFlag == true) {
                        if (start == end) {
                            flag = false;
                            ifFlag = false;
                            finished = true;
                            break;

                        }
                    }
                    if (end == (graph.get(i).getC1())) {
                        frontier.add(new Link(graph.get(i).getC1(), ' ', 1, true));
                        explored.add(new Link(graph.get(i).getC1(), ' ', 0, true));
                        flag = false;
                        end = start;
                        finished = true;
                        break;
                    }
                    if (start == (graph.get(i).getC1())) {
                        char startNode = graph.get(i).getC1();
                        temp.add(graph.get(i));
                        for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {
                            if (graph.get(i).gatC2() == (loop.getKey())) {
                                frontier.add(new Link(graph.get(i).getC1(), graph.get(i).gatC2(), loop.getValue(), true));
                            }
                        }
                        for (int x = i + 1; x < graph.size(); x++) {
                            if (startNode == (graph.get(x).getC1())) {
                                temp.add(graph.get(x));
                                for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {
                                    if (graph.get(x).gatC2() == (loop.getKey())) {
                                        frontier.add(new Link(graph.get(x).getC1(), graph.get(x).gatC2(), loop.getValue(), true));
                                    }
                                }

                                wlag = false;

                                newString = graph.get(x).getC1();

                            }
                        }
                    }
                    if (temp.size() > 0) {
                        for (int y = 0; y < temp.size(); y++) {

                            for (HashMap.Entry<Character, Integer> loop : value.entrySet()) {

                                if (temp.get(y).gatC2() == (loop.getKey())) {
                                    frontier.add(new Link(loop.getKey(), newString, loop.getValue(), true));
                                    tempClear.add(new Link(temp.get(y).getC1(), loop.getKey(), loop.getValue(), true));
                                }
                            }

                        }
                    }
                    if (temp.size() > 0) {
                        temp.clear();
                    }
                    if (tempClear.size() > 0) {
                        for (int o = 0; o < tempClear.size(); o++) {
                            for (int t = o + 1; t < tempClear.size(); t++) {
                                if (tempClear.get(o).getLinkCost() > tempClear.get(t).getLinkCost()) {
                                    float swapValue;
                                    char swapEndNode;
                                    swapEndNode = tempClear.get(t).gatC2();
                                    swapValue = tempClear.get(t).getLinkCost();
                                    tempClear.get(t).setC2(tempClear.get(o).gatC2());
                                    tempClear.get(t).setLinkCost(tempClear.get(o).getLinkCost());
                                    tempClear.get(o).setC2(swapEndNode);
                                    tempClear.get(o).setLinkCost(swapValue);
                                }

                            }
                        }
                    }
                    if (tempClear.size() > 0) {
                        explored.add(new Link(tempClear.get(0).getC1(), tempClear.get(0).gatC2(), tempClear.get(0).getLinkCost(), true));
                        start = tempClear.get(0).gatC2();
                        tempClear.clear();
                    }
                }

            }

        }
        System.out.println("1");
        for (Link print : frontier) {
            System.out.println("frontier: " + print.getC1() + " : " + print.gatC2() + " : " + print.getLinkCost());

        }
        System.out.println("--------------------------------");

        if (explored.size() == 0) {

        } else {

        }
        System.out.println("explored: ");
        for (Link print : explored) {
            
            System.out.print( print.getC1() + " : " + print.gatC2() + " : "  );
            System.out.println(print.getLinkCost());
        }
        float newCost = 0;
        boolean out = true;
        for (int hh = 0; hh < explored.size(); hh++) {

            out = true;

            for (int h = 0; h < graph.size(); h++) {

                if (out == true) {
                    if (explored.get(hh).getC1() == graph.get(h).getC1() && explored.get(hh).gatC2() == graph.get(h).gatC2() && out == true) {
                        newCost += graph.get(h).getLinkCost();
                        out = false;
                    }
                    if (explored.get(hh).gatC2() == ' ') {
                        newCost += 0;
                        out = false;
                    }

                }

            }
        }
        System.out.println("cost: " + newCost);
        System.out.println("--------------------------------");
        System.out.println("--------------------------------");

    }

}
