package searchalgorithms;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author eslam
 */
public class Node implements SearchInterface{
    
    private char name;
    private Node pParent, pNext;
    private float cost;
    private boolean explored;
    
    public Node() {
        // default constructor
    }
    
    
    public Node(char name, Node pParent, Node pNext, float cost, boolean explored) {
        
        this.name = name;
        this.pParent = pParent;
        this.pNext = pNext;
        this.cost = cost;
        this.explored = explored;
        
    }
    
    @Override
    public void setName(char name) {
        this.name = name;
    }
    
    @Override
    public char getName() {
        return name;
    }
    
    @Override
    public void setpParent(Node pParent) {
        this.pParent = pParent;
    }
    
    @Override
    public Node getpParent() {
        return pParent;
    }
    
    @Override
    public void setpNext(Node pNext) {
        this.pNext = pNext;
    }
    
    @Override
    public Node getpNext() {
        return pNext;
    }
    
    @Override
    public void setCost(float cost) {
        this.cost = cost;
    }
    
    @Override
    public float getCost() {
        return cost;
    }
    
    @Override
    public void setExplored(boolean explored) {
        this.explored = explored;
    }
    
    @Override
    public boolean getExplored() {
        return explored;
    }
    
    @Override
    public boolean isGoal(char goalCity) {
        
        return goalCity == name;
    }
    
    @Override
    public void expand(ArrayList<Link> linkList, LinkedList<Node> pFrontier) {
        
        for(int i=0; i<linkList.size(); i++) {
            for(int j=0; j<linkList.size(); j++) {
                
                if(linkList.get(i).getC1() == linkList.get(j).getC1())
                    //pushNodeToList(pFrontier);
                    pFrontier.add(this);
            }
        }
        
    }

    @Override
    public void pushNodeToList(LinkedList<Node> pFrontier) {
        
    }
    
}
